#!/usr/bin/env python3
"""Registra conversazioni con la IA, turno per turno, per poi leggerle e correggere.

A differenza di `probe_qualita.py` (una domanda secca per volta, a caso) qui ci sono
conversazioni scritte a mano, con un filo: servono a vedere se il modello tiene la scena,
se risponde, se si ripete, se ricorda. Ogni conversazione usa un personaggio diverso,
così non si sporca la memoria dell'utente.

Uso:
    python3 registra_conversazioni.py                  # tutte, con i turni previsti
    python3 registra_conversazioni.py --scenario calma
    python3 registra_conversazioni.py --turni 3        # massimo 3 turni per conversazione
    python3 registra_conversazioni.py --out /tmp/opencode/conv --pausa 2

Scrive un .md leggibile e un .jsonl per ogni conversazione, più un riepilogo finale con
lunghezza, tempi e ripetizioni. Il token scade: allo scadere si riautentica da solo.
"""
import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "backend"))
from language import parole_sconosciute  # noqa: E402

# forme già note come sbagliate: se ricompaiono, una correzione NON è scattata
FORME_NOTE = [c["sbagliato"] for c in
              json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                          "backend/language/italian-grammar.json"),
                             encoding="utf-8")).get("correzioni_brevi", [])
              if c.get("sbagliato") and c.get("giusto")]
IGNOTE = {}    # parola sospetta -> esempi
NON_CORRETTE = {}  # forma nota rimasta -> esempi

BACKEND = "http://127.0.0.1:5000"
DATI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backend/characters/data")

# Ogni conversazione: nome, categoria, indice del personaggio, turni dell'utente.
# I turni sono scritti per mettere alla prova cose diverse (vedi "cosa guarda").
CONVERSAZIONI = [
    {
        "nome": "calma",
        "cosa_guarda": "conversazione normale: risponde o svicola? resta sul pezzo?",
        "categoria": "chat-romantica",
        "indice": 70,
        "turni": [
            "Ciao, come va la giornata?",
            "Ho lavorato fino a tardi, sono distrutto",
            "Tu che hai fatto invece?",
            "Mi va di stare un po' tranquillo, niente di impegnativo",
            "Raccontami tu qualcosa, allora",
        ],
    },
    {
        "nome": "scena",
        "cosa_guarda": "continuità della scena: il luogo detto dall'utente vince sulla stanza?",
        "categoria": "camera-privata",
        "indice": 71,
        "turni": [
            "Sono in cucina, sto tagliando le verdure con il grembiule",
            "Mi sono tagliato un dito, sanguino",
            "Mi hai preso la mano, cosa fai?",
            "Dove eravamo rimasti?",
            "Riprendi da lì",
        ],
    },
    {
        "nome": "memoria",
        "cosa_guarda": "ricorda i dati dichiarati e li usa senza confondersi?",
        "categoria": "mature",
        "indice": 72,
        "turni": [
            "Ciao, mi chiamo Aldo, ho 58 anni e faccio il pescivendolo",
            "Cosa ti colpisce di me?",
            "Come mi chiamo?",
            "Quanti anni ho?",
            "Che lavoro faccio?",
        ],
    },
    {
        "nome": "erotico",
        "cosa_guarda": "sa essere esplicito senza perdere la grammatica?",
        "categoria": "dirty-talk",
        "indice": 73,
        "turni": [
            "Voglio scoparti",
            "Come lo faresti?",
            "Continua",
            "Più deciso",
            "Adesso tocca a te",
        ],
    },
    {
        "nome": "roleplay",
        "cosa_guarda": "entra nella parte e ci resta?",
        "categoria": "roleplay-erotico",
        "indice": 74,
        "turni": [
            "Facciamo che sei l'infermiera del turno di notte e io il paziente insonne",
            "Mi controlli la febbre",
            "Il termometro è freddo",
            "Mi sembra che tu ci stia prendendo gusto",
        ],
    },
    {
        "nome": "servizio",
        "cosa_guarda": "domande di servizio in mezzo alla scena: risponde e resta nella parte?",
        "categoria": "milf",
        "indice": 75,
        "turni": [
            "Ti va di uscire stasera?",
            "Che ore sono?",
            "Che giorno è oggi?",
            "Dove potremmo andare?",
            "Quindi ci vediamo?",
        ],
    },
    {
        "nome": "correzioni",
        "cosa_guarda": "accetta le correzioni o ripete l'errore?",
        "categoria": "bdsm",
        "indice": 76,
        "turni": [
            "Legami al letto",
            "No, le mani avanti",
            "Troppo stretto, allenta",
            "Va bene così. Adesso?",
        ],
    },
    {
        "nome": "lunga",
        "cosa_guarda": "dopo molti turni: si stilla, si ripete, perde il filo?",
        "categoria": "lesbo",
        "indice": 77,
        "turni": [
            "Ciao, mi chiamo Nadia e sono appena entrata",
            "Che posto è questo?",
            "Mi piace il profumo che c'è",
            "Vieni più vicina",
            "Toccami i capelli",
            "Ora baciami",
            "Dove eravamo rimasti?",
            "Riprendi",
            "Cosa ho detto all'inizio?",
            "Continua",
        ],
    },
    {
        "nome": "fuori tema",
        "cosa_guarda": "tiene la parte su domande che non c'entrano nulla?",
        "categoria": "senza-tabu",
        "indice": 78,
        "turni": [
            "Hai visto il telegiornale stasera?",
            "Conosci un ristorante qui vicino?",
            "Sai chi ha vinto la partita?",
            "Comunque, dove eravamo?",
        ],
    },
]


def scegli_dal_menu():
    """Domanda iniziale: quale tipo di test. Nessun argomento = menu interattivo."""
    print("Che tipo di test vuoi registrare?\n")
    for i, c in enumerate(CONVERSAZIONI, 1):
        print(f"  {i}. {c['nome']:12} {c['cosa_guarda']}")
    print(f"  {len(CONVERSAZIONI) + 1}. tutte")
    print("\nNumeri separati da virgola (es. 2,5), Invio = tutte, q = esci.")

    while True:
        try:
            scelta = input("\nScelta: ").strip().lower()
        except EOFError:
            return [c["nome"] for c in CONVERSAZIONI]
        if scelta in ("q", "quit", "esci"):
            sys.exit("niente da fare, esco.")
        if not scelta:
            return [c["nome"] for c in CONVERSAZIONI]
        nomi, validi = [], True
        for pezzo in scelta.replace(";", ",").split(","):
            pezzo = pezzo.strip()
            if not pezzo:
                continue
            if pezzo.isdigit():
                n = int(pezzo)
                if 1 <= n <= len(CONVERSAZIONI):
                    nomi.append(CONVERSAZIONI[n - 1]["nome"])
                elif n == len(CONVERSAZIONI) + 1:
                    return [c["nome"] for c in CONVERSAZIONI]
                else:
                    validi = False
            elif pezzo in {c["nome"] for c in CONVERSAZIONI}:
                nomi.append(pezzo)
            else:
                validi = False
        if nomi and validi:
            return list(dict.fromkeys(nomi))
        print("Scelta non valida, riprovo.")


def chiedi_turni(predefinito):
    try:
        risposta = input(f"Turni per conversazione [tutti = {predefinito}]: ").strip()
    except EOFError:
        return predefinito
    if not risposta.isdigit() or int(risposta) < 1:
        return predefinito
    return min(int(risposta), predefinito)


def token():
    tok = open("/tmp/ptk_admin.txt").read().strip()
    r = urllib.request.Request(
        BACKEND + "/auth/reauth",
        data=json.dumps({"persistent_token": tok}).encode(),
        headers={"Content-Type": "application/json"},
    )
    return json.load(urllib.request.urlopen(r, timeout=25))["access_token"]


def personaggio(categoria, indice):
    elenco = json.load(open(os.path.join(DATI, categoria + ".json"), encoding="utf-8"))
    return elenco[indice % len(elenco)]


def turno(character_id, testo, jwt):
    for tentativo in range(6):
        r = urllib.request.Request(
            BACKEND + "/chat/stream",
            data=json.dumps({"character": character_id, "text": testo, "username": "admin"}).encode(),
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + jwt},
        )
        parti = []
        try:
            with urllib.request.urlopen(r, timeout=200) as f:
                for riga in f:
                    l = riga.decode("utf-8", "replace")
                    if l.startswith("data:") and '"response"' in l:
                        try:
                            parti.append(json.loads(l[5:])["response"])
                        except Exception:
                            pass
            return parti[-1] if parti else ""
        except urllib.error.HTTPError as e:
            if e.code == 401 and tentativo < 2:
                jwt = token()
                continue
            if e.code == 429:  # risposta in corso o limite: aspetto e riprovo
                print(f"     … occupato (429), aspetto 20s", flush=True)
                time.sleep(20)
                continue
            raise
    return ""


def ripetizioni(risposte):
    """Frasi (5+ parole) già uscite in questa conversazione."""
    viste, doppie = set(), []
    for r in risposte:
        for frase in re.split(r"(?<=[.!?])\s+", r.lower()):
            frase = frase.strip(" .,!?\"")
            if len(frase.split()) >= 5:
                if frase in viste:
                    doppie.append(frase)
                viste.add(frase)
    return doppie



# ── esportazione per un correttore esterno e reimport delle correzioni ──────────
INTESTAZIONE = """Sei un correttore di lingua italiana. Ti passo conversazioni reali tra un utente e
un personaggio virtuale italiano: sono risposte generate da un modello piccolo (3 miliardi di
parametri) e servono solo per trovarne i difetti.

CONTESTO DEL PROGETTO
- Sito di chat per adulti con personaggi inventati. Registro: due adulti complici, colloquiale.
- Le risposte devono stare entro 20 parole, 1-2 frasi, dirette: prima si risponde alla domanda,
  il gesto viene dopo e non la sostituisce.
- Lessico erotico ammesso solo quando la scena lo chiede, con parole comuni.
- Vietati: terza persona narrativa, frasi fatte, verbi inventati, doppioni di parole.

COSA DEVI FARE
1. Riscrivi SOLO le righe "A", lasciando intatte le domande. Mantieni lunghezza e registro.
2. Elenca gli errori, uno per riga: `turno N | tipo | sbagliato -> corretto`
   Tipi: grammatica, verbo, persona, ripetizione, fuori-contesto, non-risponde, frase-fatta,
   lessico-sbagliato, troppo-lunga.
3. Proponi le voci da aggiungere al dizionario, in JSON, una per riga:
   {"sbagliato": "...", "giusto": "...", "nota": "..."}

FORMATO: prima il DIALOGO CORRETTO, poi gli ERRORI, poi le VOCI DIZIONARIO.
------------------------------------------------------------------

"""


def esporta_per_correzione(coppie_per_nome, cartella):
    """Un file pronto da incollare in un correttore esterno, più le stesse coppie in JSON."""
    testo, jsonl = [INTESTAZIONE], []
    for nome, coppie in coppie_per_nome.items():
        testo.append(f"### CONVERSAZIONE: {nome}\n")
        for i, (u, a) in enumerate(coppie, 1):
            testo.append(f"{i}. U: {u}\n   A: {a}\n")
            jsonl.append(json.dumps({"conversazione": nome, "turno": i, "utente": u,
                                     "risposta": a}, ensure_ascii=False))
    percorso = os.path.join(cartella, "per-chatgpt.txt")
    open(percorso, "w", encoding="utf-8").write("\n".join(testo))
    open(os.path.join(cartella, "per-chatgpt.jsonl"), "w", encoding="utf-8").write("\n".join(jsonl))
    return percorso, sum(len(c) for c in coppie_per_nome.values())


def importa_correzioni(percorso):
    """Prende le righe JSON dalla risposta del correttore e le mette nel dizionario + nei test."""
    base = os.path.dirname(os.path.abspath(__file__))
    grammatica = os.path.join(base, "backend/language/italian-grammar.json")
    verifica = os.path.join(base, "verifica_correzioni.py")
    testo = open(percorso, encoding="utf-8").read()
    voci = []
    for riga in testo.splitlines():
        riga = riga.strip().strip("`, ")
        if not riga.startswith("{"):
            continue
        try:
            d = json.loads(riga)
        except Exception:
            continue
        sbagliato, giusto = (d.get("sbagliato") or "").strip(), (d.get("giusto") or "").strip()
        if sbagliato and giusto and len(sbagliato) < 60 and len(giusto) < 60:
            voci.append({"sbagliato": sbagliato, "giusto": giusto,
                         "nota": (d.get("nota") or "esterno")[:90]})
    if not voci:
        print("nessuna voce JSON valida nel file")
        return 0
    gram = json.load(open(grammatica, encoding="utf-8"))
    esistenti = {c["sbagliato"].lower() for c in gram["correzioni_brevi"]}
    nuove = [v for v in voci if v["sbagliato"].lower() not in esistenti]
    for v in nuove:
        print(f"  {v['sbagliato']} -> {v['giusto']}")
    if nuove:
        gram["correzioni_brevi"].extend(nuove)
        json.dump(gram, open(grammatica, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        testo_v = open(verifica, encoding="utf-8").read()
        casi = "\n".join(f'    ("{v["sbagliato"]}", "{v["giusto"]}", "{v["sbagliato"]}", "importata"),'
                         for v in nuove)
        testo_v = testo_v.replace("    # regole generali, non singole parole",
                                  casi + "\n    # regole generali, non singole parole", 1)
        open(verifica, "w", encoding="utf-8").write(testo_v)
    print(f"importate {len(nuove)} voci nuove (scartate {len(voci) - len(nuove)} già presenti)")
    return len(nuove)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", action="append", help="nome della conversazione (ripetibile)")
    ap.add_argument("--turni", type=int, default=99)
    ap.add_argument("--out", default="/opt/aria/prove")
    ap.add_argument("--pausa", type=float, default=1.5)
    ap.add_argument("--importa", metavar="FILE", help="importa le correzioni da un file e basta")
    args = ap.parse_args()

    if args.importa:
        importa_correzioni(args.importa)
        return

    if args.scenario:
        scelte = [c for c in CONVERSAZIONI if c["nome"] in args.scenario]
        if not scelte:
            sys.exit("nessuna conversazione trovata: " + ", ".join(c["nome"] for c in CONVERSAZIONI))
    else:
        scelti = scegli_dal_menu()  # una chiamata sola: dentro la comprensione si ripeterebbe
        scelte = [c for c in CONVERSAZIONI if c["nome"] in scelti]
        if not args.turni or args.turni >= 99:
            args.turni = chiedi_turni(max(len(c["turni"]) for c in scelte))

    os.makedirs(args.out, exist_ok=True)
    esportati = {}
    jwt = token()
    riepilogo = []

    for conv in scelte:
        p = personaggio(conv["categoria"], conv["indice"])
        cid, nome = p["id"], p.get("name", "?")
        base = os.path.join(args.out, conv["nome"])
        risposte, tempi = [], []
        coppie_conv = []
        n_ignote = n_note = n_magre = 0
        esportati[conv["nome"]] = coppie_conv
        with open(base + ".md", "w", encoding="utf-8") as md, open(base + ".jsonl", "w", encoding="utf-8") as js:
            md.write(f"# {conv['nome']} — {nome} ({conv['categoria']})\n"
                     f"Cosa guarda: {conv['cosa_guarda']}\n\n")
            print(f"\n=== {conv['nome']} — {nome} ({conv['categoria']}) ===", flush=True)
            for i, msg in enumerate(conv["turni"][: args.turni], 1):
                t0 = time.time()
                try:
                    r = turno(cid, msg, jwt)
                except Exception as e:
                    r = f"[ERRORE: {e}]"
                dt = round(time.time() - t0, 1)
                risposte.append(r)
                coppie_conv.append((msg, r))
                tempi.append(dt)
                # analisi automatica: parole che il dizionario non conosce, correzioni
                # che non sono scattate, risposte magre a una domanda
                for w in parole_sconosciute(r, maiuscole=True):
                    IGNOTE.setdefault(w.lower(), []).append(r[:140])
                    n_ignote += 1
                minuscola = r.lower()
                for forma in FORME_NOTE:
                    if forma in minuscola:
                        NON_CORRETTE.setdefault(forma, []).append(r[:140])
                        n_note += 1
                if msg.rstrip().endswith("?") and len(r.split()) < 4:
                    n_magre += 1
                md.write(f"**{i}. U:** {msg}\n\n**A ({dt}s):** {r}\n\n")
                md.flush()
                js.write(json.dumps({"turno": i, "utente": msg, "risposta": r, "secondi": dt},
                                    ensure_ascii=False) + "\n")
                js.flush()
                print(f"  {i}. U: {msg}\n     A ({dt}s): {r[:160]}", flush=True)
                time.sleep(args.pausa)

            doppie = ripetizioni(risposte)
            md.write(f"\n---\nRipetizioni: {len(doppie)}\n")
            for d in doppie:
                md.write(f"- {d}\n")
            parole = sum(len(r.split()) for r in risposte) / max(1, len(risposte))
            md.write(f"Media parole: {parole:.1f} · Tempo medio: {sum(tempi)/max(1, len(tempi)):.1f}s\n")
            md.write(f"Parole ignote: {n_ignote} · Correggibili rimaste: {n_note} · Risposte magre: {n_magre}\n")
            riepilogo.append((conv["nome"], len(risposte), parole,
                              sum(tempi) / max(1, len(tempi)), len(doppie), sum(r == "" for r in risposte),
                              n_ignote, n_note, n_magre))
            print(f"  -> {len(doppie)} ripetizioni, {parole:.1f} parole medie", flush=True)

    print("\n=== RIEPILOGO ===")
    print(f"{'conversazione':16} {'turni':>6} {'parole':>7} {'tempo':>6} {'ripet':>6} {'vuote':>6} "
          f"{'ignote':>7} {'rimaste':>8}")
    for nome, n, parole, tempo, doppie, vuote, ignote, note, magre in riepilogo:
        print(f"{nome:16} {n:>6} {parole:>7.1f} {tempo:>5.1f}s {doppie:>6} {vuote:>6} {ignote:>7} {note:>8}")

    report = os.path.join(args.out, "da_correggere.txt")
    with open(report, "w", encoding="utf-8") as f:
        f.write("# Parole da controllare (non riconosciute dal dizionario)\n\n")
        if not IGNOTE:
            f.write("(nessuna)\n")
        for parola, esempi in sorted(IGNOTE.items(), key=lambda kv: -len(kv[1])):
            f.write(f"## {parola} ({len(esempi)} volte)\n")
            for e in dict.fromkeys(esempi) if False else list(dict.fromkeys(esempi)):
                f.write(f"- {e}\n")
            f.write("\n")
        f.write("\n# Correzioni che NON sono scattate (forma sbagliata rimasta nel testo)\n\n")
        if not NON_CORRETTE:
            f.write("(nessuna)\n")
        for forma, esempi in sorted(NON_CORRETTE.items(), key=lambda kv: -len(kv[1])):
            f.write(f"## {forma} ({len(esempi)} volte)\n")
            for e in list(dict.fromkeys(esempi)):
                f.write(f"- {e}\n")
            f.write("\n")

    print(f"\nParole da controllare: {sum(len(v) for v in IGNOTE.values())} · "
          f"correzioni non scattate: {sum(len(v) for v in NON_CORRETTE.values())}")
    for parola, esempi in sorted(IGNOTE.items(), key=lambda kv: -len(kv[1]))[:10]:
        print(f"  ? {parola} ({len(esempi)}x)  «{esempi[0][:80]}»")
    for forma in list(NON_CORRETTE)[:5]:
        print(f"  ! correzione non scattata: {forma}")
    if esportati:
        percorso_exp, turni_exp = esporta_per_correzione(esportati, args.out)
        print(f"\nDa correggere fuori: {percorso_exp} ({turni_exp} turni) — poi "
              f"`python3 chat.py --importa <risposta>`")
    print(f"\nFile in {args.out} · elenco in {report}")


if __name__ == "__main__":
    main()
