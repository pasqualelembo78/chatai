import os
import re
import tempfile
import logging
import threading

from fastapi import APIRouter, Request, Depends, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse, Response
from pydantic import BaseModel
from typing import Optional

from characters import get_character, list_characters, get_categories
from storage import is_content_unlocked, flag_user, is_age_verified
import audio_utils
import image_utils
import security_utils
from auth_fastapi import AuthUser, jwt_required
from chat_engine import process_message

from slowapi import Limiter
from slowapi.util import get_remote_address

router = APIRouter()
limiter = Limiter(key_func=get_remote_address)

logger = logging.getLogger(__name__)

# Quante generazioni sono in corso adesso: Ollama ne serve una alla volta, quindi
# il client deve sapere se sta aspettando il proprio turno o se sta scrivendo lui.
_ATTIVI = 0
_LOCK_CODA = threading.Lock()

# Una sola generazione in volo per utente: senza tetto un utente impaziente
# occupa l'unico slot e mette tutti gli altri in coda.
_IN_CORSO = {}   # user_id -> istante di inizio (None = stima scaduta)
_SCADUTO_DOPO = 240  # secondi: oltre, il lucchetto è considerato perso
_LOCK_UTENTE = threading.Lock()


def _utente_occupato(user_id):
    """True se c'è già una risposta in corso per questo utente.

    Il lucchetto è un dizionario con l'istante di inizio: se il client chiude a metà,
    il rilascio può non arrivare e l'utente resterebbe bloccato per sempre. Dopo
    _SCADUTO_DOPO secondi lo si considera perso e si riparte.
    """
    import time as _t
    with _LOCK_UTENTE:
        inizio = _IN_CORSO.get(user_id)
        if inizio is not None and (_t.time() - inizio) < _SCADUTO_DOPO:
            return True
        _IN_CORSO[user_id] = _t.time()
        return False


def _libera_utente(user_id):
    with _LOCK_UTENTE:
        _IN_CORSO.pop(user_id, None)


def _entra_coda():
    global _ATTIVI
    with _LOCK_CODA:
        _ATTIVI += 1
        return _ATTIVI


def _esci_coda():
    global _ATTIVI
    with _LOCK_CODA:
        _ATTIVI = max(0, _ATTIVI - 1)



def _send_alert(message):
    telegram_bot_token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
    if telegram_bot_token and telegram_chat_id:
        try:
            import requests as _req
            _req.post(
                f"https://api.telegram.org/bot{telegram_bot_token}/sendMessage",
                json={"chat_id": telegram_chat_id, "text": f"[ChatAI] {message[:1000]}", "parse_mode": "HTML"},
                timeout=10
            )
        except Exception as e:
            logger.warning(f"Telegram alert failed: {e}")


def _check_character_access(user_id, character):
    if not user_id:
        return False
    if character.get("is_adult") and not is_age_verified(user_id):
        return False
    category_id = character.get("category", "")
    for cat in get_categories():
        if cat["id"] == category_id:
            mvc_cost = cat.get("mvc_cost", 0)
            if mvc_cost > 0 and not is_content_unlocked(user_id, "category", category_id):
                return False
            break
    return True


class ChatRequest(BaseModel):
    character: Optional[str] = None
    text: str = ""
    username: str = "Utente"
    memory_context: Optional[list] = None
    user_memory: Optional[dict] = None
    character_data: Optional[dict] = None
    image: str = ""
    image_mime: str = "image/jpeg"
    is_favorite: bool = False
    client_storage: bool = False
    relationship_state: Optional[dict] = None
    personality_state: Optional[dict] = None
    evolution_state: Optional[dict] = None
    shifts: Optional[list] = None
    summaries: Optional[list] = None


class RedoRequest(BaseModel):
    character: str
    text: Optional[str] = None
    username: str = "Utente"
    character_data: Optional[dict] = None


class TtsRequest(BaseModel):
    text: str = ""
    character_id: str = ""


@router.post("/chat")
@limiter.limit("60/minute")
async def api_chat(request: Request, body: ChatRequest, user: AuthUser = Depends(jwt_required)):
    chars = list_characters()
    character_id = body.character or (chars[0]["id"] if chars else None)
    text = body.text
    username = body.username

    client_state = {
        "relationship": body.relationship_state,
        "personality": body.personality_state,
        "evolution": body.evolution_state,
        "shifts": body.shifts,
        "summaries": body.summaries,
    }

    if not text and not body.image:
        raise HTTPException(400, "text or image required")
    if text:
        ok, msg = security_utils.nsfw_check_text(text)
        if not ok:
            raise HTTPException(400, msg)

    char = get_character(character_id)
    if char and not _check_character_access(user.user_id, char):
        raise HTTPException(403, "premium_required")

    from storage import check_and_count_message, refund_message
    from content_safety import moderate_output
    allowed, status = check_and_count_message(user.user_id)
    if not allowed:
        raise HTTPException(
            429,
            {
                "error": "daily_limit_reached",
                "limit": status["limit"],
                "used": status["used"],
                "unlock_cost": status["unlock_cost"],
                "message": f"Limite giornaliero di messaggi raggiunto ({status['limit']}). "
                           f"Sblocca messaggi illimitati con {status['unlock_cost']} MVC.",
            },
        )

    result = process_message(user.user_id, character_id, text, username,
                             memory_context=body.memory_context,
                             user_memory=body.user_memory,
                             character_data=body.character_data,
                             image_base64=body.image,
                             image_mime=body.image_mime,
                             client_storage=body.client_storage,
                             client_state=client_state,
                             is_favorite=body.is_favorite)
    if not result:
        refund_message(user.user_id)
        raise HTTPException(404, "character not found")

    # Blocco lato server garantito (conformità Google Play): anche se il modello
    # producesse contenuti espliciti, l'output viene filtrato e sostituito.
    ai_text, _blocked = moderate_output(result["ai_text"])
    result["ai_text"] = ai_text

    resp = {
        "response": result["ai_text"],
        "emotion": result["emotion"],
        "emotion_intensity": result["intensity"],
        "ai_provider": result.get("ai_provider", ""),
        "ai_model": result.get("ai_model", ""),
        "character_id": character_id,
        "character_name": result["character"]["name"],
    }
    mem_updates = result.get("memory_updates", {})
    if mem_updates:
        resp["memory_updates"] = mem_updates
    evo_updates = result.get("evo_updates", {})
    if evo_updates.get("new_stage") or evo_updates.get("unlocked"):
        resp["evo_updates"] = evo_updates
    if body.client_storage:
        cs = result.get("client_state", {})
        if cs:
            resp["client_state"] = cs
    return resp


@router.post("/chat/stream")
@limiter.limit("60/minute")
async def api_chat_stream(request: Request, body: ChatRequest, user: AuthUser = Depends(jwt_required)):
    """Come /chat ma in Server-Sent Events: i pezzi arrivano mentre il modello scrive.

    Eventi: meta (nome personaggio), delta (testo), final (payload completo, stessa
    forma di /chat), error. Su CPU la lettura del prompt resta il costo maggiore:
    lo streaming serve a non far fissare una pagina vuota.
    """
    import json as _json
    import queue
    import threading

    chars = list_characters()
    character_id = body.character or (chars[0]["id"] if chars else None)
    text = body.text

    client_state = {
        "relationship": body.relationship_state,
        "personality": body.personality_state,
        "evolution": body.evolution_state,
        "shifts": body.shifts,
        "summaries": body.summaries,
    }

    if not text and not body.image:
        raise HTTPException(400, "text or image required")
    if text:
        ok, msg = security_utils.nsfw_check_text(text)
        if not ok:
            raise HTTPException(400, msg)

    char = get_character(character_id)
    if char and not _check_character_access(user.user_id, char):
        raise HTTPException(403, "premium_required")

    from storage import check_and_count_message, refund_message
    from content_safety import moderate_output
    allowed, status = check_and_count_message(user.user_id)
    if not allowed:
        raise HTTPException(
            429,
            {
                "error": "daily_limit_reached",
                "limit": status["limit"],
                "used": status["used"],
                "unlock_cost": status["unlock_cost"],
                "message": f"Limite giornaliero di messaggi raggiunto ({status['limit']}). "
                           f"Sblocca messaggi illimitati con {status['unlock_cost']} MVC.",
            },
        )

    if _utente_occupato(user.user_id):
        raise HTTPException(429, {
            "error": "risposta_in_corso",
            "message": "Hai già una risposta in corso: aspetta che finisca e riprova.",
        })

    coda = queue.Queue()
    posizione = _entra_coda()

    def lavora():
        try:
            result = process_message(
                user.user_id, character_id, text, body.username,
                memory_context=body.memory_context,
                user_memory=body.user_memory,
                character_data=body.character_data,
                image_base64=body.image,
                image_mime=body.image_mime,
                client_storage=body.client_storage,
                client_state=client_state,
                is_favorite=body.is_favorite,
                on_delta=lambda pezzo: coda.put(("delta", pezzo)),
            )
            coda.put(("result", result))
        except Exception as e:  # qualunque errore va raccontato al client
            logger.exception("stream/chat errore")
            coda.put(("error", str(e)))
        finally:
            _libera_utente(user.user_id)

    threading.Thread(target=lavora, daemon=True).start()

    def eventi():
        try:
            nome = (char or {}).get("name", "")
            yield "event: meta\ndata: " + _json.dumps({"character_name": nome}, ensure_ascii=False) + "\n\n"
            if posizione > 1:
                yield "event: coda\ndata: " + _json.dumps({"davanti": posizione - 1}) + "\n\n"
            while True:
                tipo, dato = coda.get()
                if tipo == "delta":
                    yield "event: delta\ndata: " + _json.dumps({"t": dato}, ensure_ascii=False) + "\n\n"
                    continue
                if tipo == "error":
                    refund_message(user.user_id)
                    yield "event: error\ndata: " + _json.dumps({"error": dato}, ensure_ascii=False) + "\n\n"
                    return
                result = dato
                if not result:
                    refund_message(user.user_id)
                    yield "event: error\ndata: " + _json.dumps({"error": "character not found"}, ensure_ascii=False) + "\n\n"
                    return
                ai_text, _bloccato = moderate_output(result["ai_text"])
                result["ai_text"] = ai_text
                payload = {
                    "response": ai_text,
                    "emotion": result["emotion"],
                    "emotion_intensity": result["intensity"],
                    "ai_provider": result.get("ai_provider", ""),
                    "ai_model": result.get("ai_model", ""),
                    "character_id": character_id,
                    "character_name": result["character"]["name"],
                }
                mem_updates = result.get("memory_updates", {})
                if mem_updates:
                    payload["memory_updates"] = mem_updates
                evo_updates = result.get("evo_updates", {})
                if evo_updates.get("new_stage") or evo_updates.get("unlocked"):
                    payload["evo_updates"] = evo_updates
                yield "event: final\ndata: " + _json.dumps(payload, ensure_ascii=False) + "\n\n"
                return
        finally:
            _esci_coda()

    return StreamingResponse(
        eventi(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
    )


@router.post("/chat/regenerate")
@limiter.limit("60/minute")
async def api_chat_regenerate(request: Request, body: RedoRequest, user: AuthUser = Depends(jwt_required)):
    """Rigenera l'ultima risposta (o la rigenera su un messaggio modificato).

    Se `text` è presente sostituisce l'ultimo messaggio dell'utente; in ogni caso
    cancella l'ultima risposta del personaggio e la rifà in streaming, senza
    aggiungere un doppione e senza consumare il limite giornaliero.
    """
    import json as _json
    import queue
    import threading

    from storage.messages import ultimo_messaggio, aggiorna_messaggio, elimina_messaggio
    from content_safety import moderate_output

    char = get_character(body.character) if body.character else None
    if not char:
        raise HTTPException(404, "character not found")
    if not _check_character_access(user.user_id, char):
        raise HTTPException(403, "premium_required")

    ultimo = ultimo_messaggio(user.user_id, body.character)
    if not ultimo:
        raise HTTPException(400, "nessun messaggio da rigenerare")

    testo = ultimo["content"]
    if body.text is not None:
        nuovo = body.text.strip()
        if not nuovo:
            raise HTTPException(400, "testo vuoto")
        ok, msg = security_utils.nsfw_check_text(nuovo)
        if not ok:
            raise HTTPException(400, msg)
        if ultimo["role"] == "user":
            aggiorna_messaggio(ultimo["id"], nuovo)
        else:
            from storage.messages import add_message
            add_message(user.user_id, body.character, "user", nuovo)
        testo = nuovo
        # la risposta precedente non è più coerente col nuovo testo
        if ultimo["role"] == "assistant":
            elimina_messaggio(ultimo["id"])
    elif ultimo["role"] == "assistant":
        elimina_messaggio(ultimo["id"])

    if _utente_occupato(user.user_id):
        raise HTTPException(429, {
            "error": "risposta_in_corso",
            "message": "Hai già una risposta in corso: aspetta che finisca e riprova.",
        })

    coda = queue.Queue()
    posizione = _entra_coda()

    def lavora():
        try:
            result = process_message(
                user.user_id, body.character, testo, body.username,
                character_data=body.character_data,
                salva_utente=False,
                on_delta=lambda pezzo: coda.put(("delta", pezzo)),
            )
            coda.put(("result", result))
        except Exception as e:
            logger.exception("regenerate errore")
            coda.put(("error", str(e)))
        finally:
            _libera_utente(user.user_id)

    threading.Thread(target=lavora, daemon=True).start()

    def eventi():
        try:
            yield "event: meta\ndata: " + _json.dumps({"character_name": char.get("name", "")}, ensure_ascii=False) + "\n\n"
            if posizione > 1:
                yield "event: coda\ndata: " + _json.dumps({"davanti": posizione - 1}) + "\n\n"
            while True:
                tipo, dato = coda.get()
                if tipo == "delta":
                    yield "event: delta\ndata: " + _json.dumps({"t": dato}, ensure_ascii=False) + "\n\n"
                    continue
                if tipo == "error":
                    yield "event: error\ndata: " + _json.dumps({"error": dato}, ensure_ascii=False) + "\n\n"
                    return
                result = dato
                if not result:
                    yield "event: error\ndata: " + _json.dumps({"error": "character not found"}, ensure_ascii=False) + "\n\n"
                    return
                testo_finale, _b = moderate_output(result["ai_text"])
                payload = {
                    "response": testo_finale,
                    "emotion": result["emotion"],
                    "ai_model": result.get("ai_model", ""),
                    "character_name": result["character"]["name"],
                }
                yield "event: final\ndata: " + _json.dumps(payload, ensure_ascii=False) + "\n\n"
                return
        finally:
            _esci_coda()

    return StreamingResponse(
        eventi(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/health/stato")
async def api_health_stato():
    """Stato interno per il watchdog RAM: quante generazioni in corso."""
    return {"attivi": _ATTIVI}


@router.get("/chat/export")
async def api_chat_export(character: str, user: AuthUser = Depends(jwt_required)):
    """Conversazione completa in testo semplice, per il download."""
    from storage.messages import storico_completo

    char = get_character(character)
    if not char:
        raise HTTPException(404, "character not found")

    righe = [f"Conversazione con {char.get('name', '')} — {char.get('category', '')}", ""]
    for m in storico_completo(user.user_id, character):
        chi = char.get("name", "Personaggio") if m["role"] == "assistant" else "Tu"
        quando = m["timestamp"].strftime("%d/%m/%Y %H:%M") if m.get("timestamp") else ""
        righe.append(f"[{quando}] {chi}: {m['content']}")
        righe.append("")

    corpo = "\n".join(righe)
    nome = f"{char.get('name', 'personaggio').replace(' ', '-').lower()}.txt"
    return Response(
        content=corpo.encode("utf-8"),
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{nome}"'},
    )



def _prima_persona(tratto, nome):
    """Porta in prima persona un tratto scritto in terza ("X è una persona...")."""
    t = re.sub(r"\s+", " ", str(tratto or "")).strip()
    frasi = re.split(r"(?<=[.!?])\s+", t) if t else []
    t = " ".join(frasi[:2]).strip()
    if not t:
        return ""
    # il tratto può iniziare con il nome vero o con quello vecchio: in entrambi i casi
    # va portato in prima persona
    t = re.sub(r"^[A-ZÀ-Ý][\w'’]+(?:\s+[A-ZÀ-Ý][\w'’]+)?\s+è\s+", "sono ", t)
    t = re.sub(r"^[A-ZÀ-Ý][\w'’]+(?:\s+[A-ZÀ-Ý][\w'’]+)?\s+ha\s+", "ho ", t)
    # verbi in terza persona -> prima persona (solo forme non ambigue)
    for a, b in ((" sa ", " so "), (" ama ", " amo "), (" ha ", " ho "),
                 (" predilige ", " prediligo "), (" preferisce ", " preferisco "),
                 (" conduce ", " conduco "), (" cerca ", " cerco ")):
        t = t.replace(a, b)
    t = re.sub(r"^Ha\s+", "Ho ", t)
    t = re.sub(r"^È\s+", "Sono ", t)
    if t:
        t = t[0].upper() + t[1:]
    return t[:150]


def _presentazione(char, meta, seme):
    """Presentazione immediata (prima del modello), 40-65 parole, in prima persona.

    Costruita SOLO su dati del personaggio. La scrive il modello subito dopo; questa
    serve a non lasciare la stanza vuota e a dare una traccia con la struttura giusta.
    """
    nome = char.get("name") or "Io"
    eta = char.get("age")
    lavoro = (char.get("job") or "").strip()
    categoria = meta.get("name", "")
    descrizione = (meta.get("description") or "").strip().lower()
    tag = [t for t in (char.get("tags") or []) if isinstance(t, str)][:3]
    tratto = _prima_persona(char.get("personality"), nome)

    chi = f"Sono {nome}"
    if eta:
        chi += f", {eta} anni"
    if lavoro:
        chi += ", e faccio " + lavoro[0].lower() + lavoro[1:]
    chi += "."

    stanza = [
        f"Mi trovi nella stanza {categoria}",
        f"Sto nella stanza {categoria}",
        f"Sono qui, nella stanza {categoria}",
    ][seme % 3]
    if descrizione:
        stanza += ": " + descrizione
    stanza += "."

    frasi = [chi, stanza]
    if tratto:
        frasi.append(tratto)
    if tag and len(" ".join(frasi).split()) < 42:
        frasi.append([
            "Chi mi cerca sa che mi muovo tra " + ", ".join(tag) + ".",
            "Mi riconosci da " + ", ".join(tag) + ".",
            "I temi che porto sono " + ", ".join(tag) + ".",
        ][seme % 3])

    inviti = [
        "Dimmi tu da dove partiamo.",
        "Scrivimi due righe e cominciamo.",
        "Ti va di fare la prima mossa?",
        "Raccontami perché sei entrato.",
    ]

    testo = " ".join(frasi)

    # porta il testo dentro la misura richiesta (40-65) con agganci pertinenti
    from characters import category_profiles as _cp
    _prof = _cp.profile_for(meta.get("id", ""))
    riempitivi = []
    if _prof.get("approach"):
        _v2 = {
            "accorci": "accorcio", "agisci": "agisco", "allunghi": "allungo", "alterni": "alterno",
            "ascolti": "ascolto", "avvicini": "avvicino", "bruci": "brucio", "chiedi": "chiedo",
            "comandi": "comando", "commenti": "commento", "concedi": "concedo", "controlli": "controllo",
            "correggi": "correggo", "dai": "do", "descrivi": "descrivo", "dici": "dico", "entri": "entro",
            "fai": "faccio", "faresti": "farei", "giochi": "gioco", "guidi": "guido", "imbarazzi": "imbarazzo",
            "lasci": "lascio", "leggi": "leggo", "lodi": "lodo", "mantieni": "mantengo", "metti": "metto",
            "mostri": "mostro", "neghi": "nego", "parli": "parlo", "prendi": "prendo", "proponi": "propongo",
            "racconti": "racconto", "reagisci": "reagisco", "ricordi": "ricordo", "ringrazi": "ringrazio",
            "rispondi": "rispondo", "sottolinei": "sottolineo", "sottometti": "sottometto", "spingi": "spingo",
            "tieni": "tengo", "togli": "tolgo", "valuti": "valuto", "vedi": "vedo", "verifichi": "verifico",
            "vorresti": "vorrei", "vuoi": "voglio",
        }
        _riflessivi = {
            "ti soffermi": "mi soffermo", "ti avvicini": "mi avvicino", "ti muovi": "mi muovo",
            "ti imbarazzi": "mi imbarazzo", "ti sottometti": "mi sottometto", "ti esibisci": "mi esibisco",
            "ti lasci": "mi lascio", "ti metti": "mi metto", "ti togli": "mi tolgo",
        }
        _app = str(_prof["approach"]).strip()
        for a, b in _riflessivi.items():
            _app = _app.replace(a, b)
        _app = re.sub(r"\b(" + "|".join(_v2) + r")\b", lambda m: _v2[m.group(1)], _app)
        riempitivi.append("Come mi muovo: " + _app + ".")
    riempitivi += [
        "Non serve sapere niente in anticipo: si costruisce scrivendo.",
        "Basta un saluto per iniziare.",
        "Qui funziona meglio se ti butti.",
    ]
    i = 0
    while len(testo.split()) < 40 and i < len(riempitivi):
        testo += " " + riempitivi[i]
        i += 1
    testo += " " + inviti[seme % len(inviti)]

    # se esagera, taglia all'ultima frase entro 65 parole
    parole = testo.split()
    if len(parole) > 65:
        taglio = " ".join(parole[:65])
        punto = max(taglio.rfind("."), taglio.rfind("?"), taglio.rfind("!"))
        testo = taglio[:punto + 1] if punto > 40 else taglio + "."
    return testo


@router.post("/chat/spunto")
@limiter.limit("30/minute")
def api_chat_spunto(request: Request, body: ChatRequest, user: AuthUser = Depends(jwt_required)):
    """Uno spunto: una domanda breve che il personaggio fa per rompere il ghiaccio.

    Serve al pulsante "?" per chi entra in chat e non sa da dove cominciare.
    Non consuma il limite giornaliero e non entra in cronologia: è solo un suggerimento.
    """
    from ai_engine.response import get_ai_response

    char = get_character(body.character) if body.character else None
    if not char:
        raise HTTPException(404, "character not found")
    if not _check_character_access(user.user_id, char):
        raise HTTPException(403, "premium_required")

    nome = char.get("name", "il personaggio")
    contesto = (char.get("category_context") or "")[:220]
    sistema = (f"Sei {nome}. {contesto}\n"
               "Scrivi una domanda naturale, breve, che faresti a voce all'inizio della chat, "
               "in italiano e coerente col tuo carattere. Come una persona vera, non come un assistente. "
               "Massimo 8 parole. Deve riguardare lui, lei o il momento, e deve avere senso "
               "anche da sola: chi la legge deve poter rispondere. "
               "Esempi: 'Ti va se chiudo la porta?', 'Perché sei qui a quest'ora?', "
               "'Da dove vuoi cominciare?'. "
               "Attenzione a 'venire': si dice 'Perché mi hai fatto venire qui?', non "
               "'Cosa mi hai fatto venire qui?'. Solo la domanda, senza virgolette.")
    messaggi = [{"role": "system", "content": sistema},
                {"role": "user", "content": "Dammi la domanda."}]

    testo = ""
    try:
        testo, _p, _m = get_ai_response(messaggi, user_id=user.user_id)
    except Exception as e:
        logger.warning(f"spunto fallito: {e}")

    testo = (testo or "").strip().splitlines()[0] if testo else ""
    # una sola domanda: se ne incastra due, tengo la prima
    if testo.count("?") > 1:
        testo = testo.split("?")[0] + "?"
    testo = testo.strip('"«» ').rstrip(" .,;:")
    testo = re.sub(r"(?i)^cosa mi (hai|fai) (fatto )?venire\b", "perché mi hai fatto venire", testo)
    testo = re.sub(r"(?i)^cosa (ti|le) (ha|fa) (fatto )?venire\b", "perché ti ha fatto venire", testo)
    testo = re.sub(r"(?i)\b(mi|ti|si) fa sentirti\b", lambda m: m.group(1) + " fa sentire", testo)
    if testo and not testo.endswith(("?", "!", "…")):
        testo += "?"
    if len(testo.split()) > 10:
        testo = " ".join(testo.split()[:10]).rstrip(",;:") + "?"
    if not testo:
        testo = _SPUNTI.get(char.get("category", ""), "Da dove cominciamo?")
    return {"testo": testo}


# ripiego se il modello non risponde: una domanda per stanza
_SPUNTI = {
    "bdsm": "Da dove vuoi che cominci?", "dirty-talk": "Quanto ti senti sporca stasera?",
    "chat-romantica": "Che cosa ti ha fatto sorridere oggi?",
    "milf": "Ti va di stare un po' con me?", "lesbo": "Posso avvicinarmi?",
    "gay": "Che cosa cerchi stasera?", "mature": "Di cosa hai voglia di parlare?",
    "roleplay-erotico": "Che parte vuoi fare tu?",
    "senza-tabu": "Fin dove ti spingi?", "threesome": "Chi comincia?",
    "voyeurismo": "Posso guardarti?", "camera-privata": "Da dove iniziamo?",
}


@router.post("/chat/opening")
@limiter.limit("30/minute")
async def api_chat_opening(request: Request, body: ChatRequest, user: AuthUser = Depends(jwt_required)):
    """Il personaggio apre lui la conversazione.

    Prima riga: template della stanza, immediato (0 ms). Subito dopo il modello
    riscrive l'apertura in streaming e la sostituisce. Non consuma il limite
    giornaliero; si salta se la conversazione è recente.
    """
    import json as _json
    import queue
    import threading
    import hashlib

    from characters import category_profiles as cp
    from storage import get_recent_messages
    from prompt_builder import build_messages

    character_id = body.character
    char = get_character(character_id) if character_id else None
    if not char:
        raise HTTPException(404, "character not found")
    if not _check_character_access(user.user_id, char):
        raise HTTPException(403, "premium_required")

    inattivita = int(os.environ.get("OPENING_IDLE_MINUTES", "30"))
    ultimo = _ultimo_messaggio(user.user_id, character_id)
    logger.info(f"opening guard: ultimo={ultimo} inattivita={inattivita}")
    if ultimo:
        import time as _time
        if (_time.time() - ultimo) < inattivita * 60:
            return JSONResponse({"skip": True, "reason": "conversation_active"})

    prof = cp.profile_for(char.get("category", ""))
    try:
        from characters import CATEGORIES as _CATS
        meta_stanza = next((c for c in _CATS if c["id"] == char.get("category")), None)
    except Exception:
        meta_stanza = None
    if not meta_stanza:
        meta_stanza = {"id": char.get("category", ""), "name": char.get("category", ""), "description": ""}
    seme = int(hashlib.md5(f"{user.user_id}:{character_id}".encode()).hexdigest()[:8], 16)
    template = _presentazione(char, meta_stanza, seme)

    history = get_recent_messages(user.user_id, character_id, limit=6)

    def sistema():
        # Prompt compatto: per un'apertura non serve tutta la biografia, e su CPU
        # ogni 100 token in meno sono secondi risparmiati.
        essenza = str(char.get("essence") or "").split("Stanza tematica:")[0].strip()
        dati = [f"Nome: {char.get('full_name') or char.get('name')}"]
        if char.get("age"):
            dati.append(f"Età: {char['age']}")
        if char.get("job"):
            dati.append(f"Mestiere: {char['job']}")
        if essenza:
            dati.append("Storia: " + essenza[:200])
        if char.get("personality"):
            dati.append("Carattere: " + str(char["personality"])[:200])
        if char.get("tags"):
            dati.append("Parole chiave: " + ", ".join([t for t in char["tags"] if isinstance(t, str)][:4]))
        dati.append(f"Stanza: {meta_stanza.get('name')} — {meta_stanza.get('description', '')}")
        blocchi = [
            f"Sei {char.get('full_name') or char.get('name')} e stai aprendo la conversazione.",
            "Presentati in PRIMA persona all'utente che ha appena aperto la chat.",
            "Regole: 40-65 parole, massimo quattro frasi. Usa SOLO i dati elencati, non inventare "
            "fatti nuovi. Struttura: (1) nome, età o mestiere; (2) la stanza in cui sei e cosa si "
            "fa lì; (3) un tratto del tuo carattere e come ti relazioni; (4) una chiusura naturale "
            "che inviti a rispondere.",
            "Tono coerente con la stanza, niente elenchi, niente presentazioni formali, parla di te in prima persona.",
            "Racconta cosa fai tu, non elencare istruzioni all'utente: se dici la stanza, fallo in "
            "modo naturale invece di copiarne la descrizione.",
            "Non ricopiare la traccia: riformula tutto con parole tue, aggiungi un dettaglio concreto "
            "(il mestiere, l'età, un gesto che fai di solito) e chiudi con un invito diverso.",
            "DATI:\n" + "\n".join("- " + d for d in dati),
            "SCHEMA: 1) nome, età o mestiere. 2) la stanza in cui sei. 3) come sei fatto e come ti relazioni. 4) invito a rispondere.",
        ]
        return [{"role": "system", "content": "\n\n".join(blocchi)}]

    coda = queue.Queue()

    def lavora():
        try:
            msgs = sistema()
            from ai_engine.streaming import get_ai_response_stream
            completo = ""
            avviato = False
            for token, _pid, _mid in get_ai_response_stream(msgs, user_id=user.user_id):
                if not token:
                    continue
                completo += token
                if not avviato:
                    # il template chatml fa riecheggiare "assistant"/a capo iniziali
                    ripulito = re.sub(r'^assistant\s*[:\n]*["\s]*', "", completo, flags=re.I)
                    if not ripulito.strip():
                        continue
                    avviato = True
                    coda.put(("delta", ripulito))
                    continue
                coda.put(("delta", token))
            testo = re.sub(r'^assistant\s*[:\n]*["\s]*', "", completo, flags=re.I).strip()
            testo = testo.strip('"').strip("«»“”").strip()
            parole = len(testo.split())
            logger.info(f"opening generato: {parole} parole")
            if parole < 32:
                testo = template + (" " + testo if testo else "")
            coda.put(("result", testo))
        except Exception as e:
            logger.exception("opening errore")
            coda.put(("result", ""))

    threading.Thread(target=lavora, daemon=True).start()

    def eventi():
            yield "event: template\ndata: " + _json.dumps({"text": template}, ensure_ascii=False) + "\n\n"
            testo = ""
            while True:
                tipo, dato = coda.get()
                if tipo == "delta":
                    yield "event: delta\ndata: " + _json.dumps({"t": dato}, ensure_ascii=False) + "\n\n"
                    continue
                testo = dato or ""
                if not testo:
                    # modello muto: resta il template
                    yield "event: final\ndata: " + _json.dumps({"text": template, "template": True}, ensure_ascii=False) + "\n\n"
                    return
                try:
                    from storage import add_message
                    add_message(user.user_id, character_id, "assistant", testo)
                except Exception:
                    logger.warning("salvataggio apertura fallito", exc_info=True)
                yield "event: final\ndata: " + _json.dumps({"text": testo}, ensure_ascii=False) + "\n\n"
                return

    return StreamingResponse(
        eventi(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


def _ultimo_messaggio(user_id, character_id):
    """Timestamp (epoch) dell'ultimo messaggio della coppia utente+personaggio."""
    from db import get_conn, put_conn
    conn = get_conn()
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT EXTRACT(EPOCH FROM MAX(timestamp)) AS ultimo FROM messages WHERE user_id=%s AND character_id=%s",
            (user_id, character_id),
        )
        riga = cur.fetchone()
        if not riga:  # il cursore restituisce righe-dizionario
            return 0.0
        valore = riga["ultimo"] if "ultimo" in riga else list(riga.values())[0]
        return float(valore) if valore else 0.0
    except Exception:
        return 0.0
    finally:
        put_conn(conn)


@router.post("/transcribe")
@limiter.limit("10/minute")
async def api_transcribe(request: Request, audio: UploadFile = File(...), user: AuthUser = Depends(jwt_required)):
    if not audio.filename or audio.filename.strip() == "":
        raise HTTPException(400, "audio file required")
    if not audio_utils.allowed_audio_file(audio.filename):
        raise HTTPException(400, "formato audio non supportato")

    content = await audio.read()
    path = tempfile.mktemp(suffix=os.path.splitext(audio.filename)[1])
    with open(path, "wb") as f:
        f.write(content)

    ok, msg = security_utils.validate_file_mime(path, os.path.splitext(audio.filename)[1])
    if not ok:
        try: os.remove(path)
        except Exception: pass
        raise HTTPException(400, msg)

    ok, msg = security_utils.scan_file(path)
    if not ok:
        try: os.remove(path)
        except Exception: pass
        _send_alert(f"⚠️ File infetto rilevato — user={user.user_id} detail={msg}")
        raise HTTPException(400, msg)

    ok, msg = security_utils.validate_audio_duration(path)
    if not ok:
        try: os.remove(path)
        except Exception: pass
        raise HTTPException(400, msg)

    ok, msg = security_utils.validate_audio_sample_rate(path)
    if not ok:
        try: os.remove(path)
        except Exception: pass
        raise HTTPException(400, msg)

    text = audio_utils.transcribe_audio(path)
    try: os.remove(path)
    except Exception: pass
    if not text:
        raise HTTPException(500, detail="transcription failed")
    return {"text": text}


@router.post("/tts")
async def api_tts(body: TtsRequest, user: AuthUser = Depends(jwt_required)):
    if not body.text:
        raise HTTPException(400, "text required")
    if not is_content_unlocked(user.user_id, "feature", "premium_voice"):
        raise HTTPException(403, "premium_voice_required")
    char = get_character(body.character_id) if body.character_id else None
    voice_profile = audio_utils.get_voice_profile(char) if char else {"model": "it_IT-riccardo-medium", "speed": 1.0, "pitch": 1.0}
    output_path = audio_utils.text_to_speech(body.text, voice_profile)
    if not output_path:
        raise HTTPException(500, "TTS generation failed")

    def generate():
        with open(output_path, "rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                yield chunk
        try: os.remove(output_path)
        except Exception: pass

    return StreamingResponse(generate(), media_type="audio/wav",
                             headers={"Content-Disposition": "inline; filename=response.wav"})


@router.post("/upload-image")
@limiter.limit("10/minute")
async def api_upload_image(request: Request, image: UploadFile = File(...), user: AuthUser = Depends(jwt_required)):
    if not image.filename or image.filename.strip() == "":
        raise HTTPException(400, "image file required")
    if not image_utils.validate_image(image.filename):
        raise HTTPException(400, "invalid image format (jpg/png/webp only)")

    content = await image.read()
    if len(content) > image_utils.MAX_IMAGE_SIZE:
        raise HTTPException(400, "image too large (max 10MB)")

    ext = os.path.splitext(image.filename)[1]
    path = tempfile.mktemp(suffix=ext)
    with open(path, "wb") as f:
        f.write(content)

    ok, msg = security_utils.validate_file_mime(path, ext)
    if not ok:
        try: os.remove(path)
        except Exception: pass
        raise HTTPException(400, msg)

    ok, msg = security_utils.scan_file(path)
    if not ok:
        try: os.remove(path)
        except Exception: pass
        _send_alert(f"⚠️ Immagine infetta rilevata — user={user.user_id} detail={msg}")
        raise HTTPException(400, msg)

    ok, msg = security_utils.nsfw_check_image(path)
    if not ok:
        flag_user(user.user_id, f"NSFW image: {msg}", "image", msg, "high")
        try: os.remove(path)
        except Exception: pass
        _send_alert(f"🔞 NSFW rilevato — user={user.user_id} reason={msg}")
        raise HTTPException(400, "Contenuto non appropriato")

    security_utils.strip_exif(path)
    path = image_utils.resize_image(path)
    b64 = image_utils.image_to_base64(path)
    mime = security_utils.EXT_TO_MIME.get(ext, "image/jpeg")
    try: os.remove(path)
    except Exception: pass
    return {"base64": b64, "mime": mime}


@router.get("/static/videos/{filename}")
async def api_video(filename: str):
    if not re.match(r"^[a-f0-9]{32}\.mp4$", filename):
        raise HTTPException(400, "invalid")
    video_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "static", "videos", filename)
    if not os.path.isfile(video_path):
        raise HTTPException(404, "not found")
    return FileResponse(video_path, media_type="video/mp4")
